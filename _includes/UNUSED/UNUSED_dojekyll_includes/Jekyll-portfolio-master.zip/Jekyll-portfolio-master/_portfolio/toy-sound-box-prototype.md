---
cover: IMG_20191211_140908.jpg
title: Toy sound box prototype
tags: design prototype model
modal:
  - img: sound_box_proto_281119a_bb-1024x523.png
  - img: IMG_20191209_141424.jpg
  - img: IMG_20191211_100130.jpg
  - img: IMG_20191211_140908.jpg
  - img: IMG_20191211_141814.jpg
  - img: IMG_20191211_141828.jpg
---

A working model prototype for usability testing of a sound box in a plush toy which is under development.
Usability tested for sound box size, operation and ease of use, and loudness.
Contract work.