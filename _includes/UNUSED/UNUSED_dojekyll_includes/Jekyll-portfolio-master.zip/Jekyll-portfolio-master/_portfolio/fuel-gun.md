---
cover: 4-1024x768.jpg
title: "Injection molding - mold approval"
tags: plastics-engineering injection-molding
modal:
  - img: 3-1024x768.jpg
  - img: 2-1024x768.jpg
  - img: 1-1024x768.jpg
  - img: 4-1024x768.jpg
---

Approval of molded products produced by "Supergum" as contracted work.
Parts were approved according to customer's requirements, and were collaboratively designed with a leading design studio. 