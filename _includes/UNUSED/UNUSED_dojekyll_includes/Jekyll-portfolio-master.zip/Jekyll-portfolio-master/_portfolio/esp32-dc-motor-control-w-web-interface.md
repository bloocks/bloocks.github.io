---
cover: 
title: "2 DC motors moving in tandem w/ AP for control and monitoring"
tags: control arduino
link: https://github.com/UriShX/portfolio/blob/master/Roboclaw_control_over_ESP32_with_AP_for_control/roboclaw_esp32_w_AP_and_config.ino
modal:
  - code: 
      link: https://raw.githubusercontent.com/UriShX/portfolio/master/Roboclaw_control_over_ESP32_with_AP_for_control/roboclaw_esp32_w_AP_and_config.ino
      lang: cpp
  # - linenos: linenos
---
ESP32 & Roboclaw control for exhibition in museum.