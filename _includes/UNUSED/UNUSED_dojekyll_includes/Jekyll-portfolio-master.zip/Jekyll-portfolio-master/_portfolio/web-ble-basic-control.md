---
cover: ble_slider_web_app_2.png
title: "Web-BLE control app + esp32 sketches"
tags: iot control
link: https://github.com/UriShX/ESP32_fader
modal:
  - md: https://raw.githubusercontent.com/UriShX/ESP32_fader/master/readme.md
  - img: ble_slider_web_app_2.png
  - img: ble_slider_web_app_1.png
---
A web-ble responsive web app to demonstrate control over BLE of ESP32 projects. 
Includes links to github repo of web app, and to a couple of ESP32 sketches for testing.