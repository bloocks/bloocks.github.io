---
cover: IMG_20190925_083954-1024x768.jpg
title: Mechanical Sieve - Shachar Marcus, MUZA, 2019
tags: mechanical control
modal:
  - img: Screenshot_20191003-094618-485x1024.png
  - img: IMG_20190918_132954-768x576.jpg
  - img: ezgif.com-optimize-2.gif
  - img: IMG_20190925_083954-1024x768.jpg
  - img: IMG_20190925_090019-768x1019.jpg
---

Mechanical and electrical design, along with programming. Creating a working installation from the artist's concept. Construction in collaboration with Studio Omri Ben Artzi, for the exhibition "Data Mining", Shachar Marcus, MUZA, 2019.