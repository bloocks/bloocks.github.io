---
cover: IMG_0778-768x576.jpg
title: "AB4MC"
tags: control prototype
link: https://hackaday.io/project/109296-arduino-blocks-for-midi-controllers
modal:
  - img: AB4MC-blockly-768x440.png
  - img: IMG_0779-768x576.jpg
  - img: IMG_0777-768x576.jpg
  - img: IMG_0794-768x576.jpg
  - img: IMG_0692_crop-768x434.jpg
  - img: IMG_0778-768x576.jpg
---
A prototyping platform for musicians, based on  Arduino and a graphical programming environment.
An ongoing project, open hardware and software.