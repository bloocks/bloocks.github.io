---
cover: 
title: "Raspberry Pi - play video when button pressed"
tags: video control raspberry-pi
link: https://github.com/UriShX/portfolio/blob/master/Raspberry_Pi_play_video_with_GPIO/rPi_play_video_w_GPIO.py
modal:
  - code:
      link: https://raw.githubusercontent.com/UriShX/portfolio/master/Raspberry_Pi_play_video_with_GPIO/rPi_play_video_w_GPIO.py
      lang: python
      # linenos: linenos="1 22"
---
Written for a commercial exhibition, video plays when a user inserts a 'coin' to a slot in the enclosure.