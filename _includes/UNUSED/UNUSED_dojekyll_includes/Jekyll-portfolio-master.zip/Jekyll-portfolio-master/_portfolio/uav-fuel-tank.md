---
cover: IMG-20180328-WA0004.jpg
title: "Design for plastic injection molding: UAV fuel tank."
tags: plastics-engineering cad cae injection-molding
modal:
  - img: fuel-tank-cad-iso.png
  - img: fuel-tank-cad-bot.png
  - img: fuel-tank-bottom-heat.png
  - img: IMG-20180328-WA0004.jpg
---

Material selection, redesign of costumer's basic design concept, inc. mechanical and Moldflow  FAE, mold design approval and parts approval.
Salaried work for Supergum, as principal design engineer, for security sector costumer.