---
cover: I-vs-Us_motor-and-links.jpeg
title: I vs. Us, Riki Stollar, 2020
tags: mechanical
modal:
  - img: I-vs-Us_portrait.jpeg
  - img: I-vs-Us_motor-and-links.jpeg
---

Mechanical design. Design a working mechnical system from the artist's concept. Construction in collaboration with the artist, for exhibition. Riki Stollar, 2020.