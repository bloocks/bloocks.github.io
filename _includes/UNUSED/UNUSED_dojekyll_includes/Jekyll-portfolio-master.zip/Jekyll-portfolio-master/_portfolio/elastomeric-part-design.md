---
cover: rotating-boot-cover-768x576.png
title: "Elastomeric part design"
tags: plastics-engineering cad elastomer
modal:
  - img: Lens-bumper-PU-768x576.png
  - img: flat-cut-seal-with-space-for-vulcanized-connection-768x576.png
  - img: rotating-boot-cover-768x576.png
---
As part of my salaried work for Supergum, I was involved in design and design for manufacture of multiple elastomer parts.
As part of my work there I was involved in elastomeric material selection, advising customers on design decisions, and fitting processes and technologies for particular products.