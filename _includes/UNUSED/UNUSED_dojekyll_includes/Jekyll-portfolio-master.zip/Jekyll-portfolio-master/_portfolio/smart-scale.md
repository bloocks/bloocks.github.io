---
place: 1
cover: IMG_20190429_161110.jpg
title: Smart kitchen scale for bread dough
link: https://hackaday.io/project/164849-yet-another-smart-kitchen-scale
tags: iot prototype model
modal:
  - img: IMG_20190429_161110.jpg
  - img: IMG_20190429_160952_cropped.jpg
  - img: ESP32_weight_scale_bb.png
---
An ESP32 based kitchen scale for bread baking. Connects to Google sheets over WiFi to retrieve bread formulas, and to save measured weight of ingredients.
BLE serves to define WiFi, as well as display current measurement.
Calculates baker's percentage on the fly.