---
cover: warning-ball-test-768x432.jpg
title: "Design for plastic injection molding: UAV fuel tank."
tags: plastics-engineering elastomer injection-molding cad mechanical
modal:
  - img: warning-ball-test-768x432.jpg
  - img: warning-ball-change-drawing-768x406.png
  - img: 1182_f11269c96d3b4fcf65e73279e52cef6b.jpg
  - img: warning-ball-lips-closed-768x490.png
---
Design change in a flagship product, fueled by failure analysis. Lead engineer, salaried work for "Supergum".
Mold and material change for high current aerial warning marker, after appearing to be part of a point failure. A comprehensive failure analysis, and mechanical testing of the new design lead to verified changes.