---
cover: concrete-pot-deformation-in-1024x531.jpg
title: "Feasibility study: Concrete pot"
tags: plastics-engineering cad cae injection-molding
modal:
  - img: concrete-pot-whole-768x444.png
  - img: concrete-pot-strain-out-1024x531.jpg
  - img: concrete-pot-loads-and-fixtures.png
  - img: concrete-pot-deformation-in-1024x531.jpg
---
Mechanical FEA of plastic injection molded concrete pouring pot, first step in approval for customer's design.
Salaried work for "Supergum", for a customer manufacturing land stabilizing solutions.