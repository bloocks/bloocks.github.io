---
cover: 2nd_iteration_rounded_handle_vonMises-768x432.png
title: "Static forces analysis for heat formed foot-rest"
tags: cae design model
modal:
  - img: 2nd_iteration_rounded_handle_vonMises-768x432.png
  - img: 1st_iteration_displacement-768x432.png
  - img: ziv-stool-03-578x1024.jpg
  - img: ziv-stool-01-768x576.jpg
---
Stress and strain validation of a heat formed foot-rest concept. Design by Ziv Mishan, for his graduation project in product design at H.I.T.. Characterization of applied forces, appropriate model, and several iterations based on slight changes in geometry, based on client's original design file. A report was produced to convey suggested changes in design.