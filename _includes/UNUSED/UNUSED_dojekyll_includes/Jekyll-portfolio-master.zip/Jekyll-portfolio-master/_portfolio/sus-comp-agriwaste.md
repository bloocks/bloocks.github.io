---
cover: dual-extruder-straw.jpg
title: "Sustainable composites from agricultural waste"
tags: plastics-engineering
link: https://onlinelibrary.wiley.com/doi/abs/10.1002/pc.24472
modal:
  - img: Poster-straw-pp-composites-768x1097.png
  - img: filtration.jpg
  - img: dual-extruder-straw.jpg
---
Scientific article, published in "Polymer Composites". Based on my plastics engineering graduation project at Shenkar College for engineering and Design.