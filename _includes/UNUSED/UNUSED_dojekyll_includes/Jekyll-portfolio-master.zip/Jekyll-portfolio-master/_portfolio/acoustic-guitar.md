---
place: 5
cover: IMG_0810-768x576.jpg
title: "Acoustic guitar"
tags: model
link: 
modal:
  - img: IMG_0809-768x576.jpg
  - img: Guitar-head-768x1024.jpg
  - img: Guitar-from-top-649x1024.jpg
  - img: IMG_0810-768x576.jpg
---
Hand built acoustic guitar. Designed and built by me during my studies with Paul Doyle at The Irish School of Lutherie. 
Top - Spruce. Back and Sides - Maple. Neck - London Plain.