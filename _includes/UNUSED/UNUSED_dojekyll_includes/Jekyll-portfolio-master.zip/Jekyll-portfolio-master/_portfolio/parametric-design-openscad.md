---
cover: SHF_for_print-768x540.png
title: "Parametric design for 3D printing"
tags: cad design
link: https://www.thingiverse.com/UriShX/designs
modal:
  - img: SHF_for_print-768x540.png
  - img: IMG_0804-768x576.jpg
  - img: AC_hose_adaptor-768x507.png
  - img: IMG_0780-768x576.jpg
  - img: IMG_0783-768x576.jpg
  - img: IMG_0781-768x576.jpg
  - img: tertial-doghole-adapter-768x540.png
  - img: IMG_0805-768x576.jpg
  - img: IMG_0800-768x576.jpg
---
Various 3D printed adapters, replacements, and fixes.
Designed in OpenSCAD.