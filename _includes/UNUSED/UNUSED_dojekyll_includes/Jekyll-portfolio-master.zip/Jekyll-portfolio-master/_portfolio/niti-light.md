---
cover: 11894545_10207114581966072_1589272026712605774_o_10207114581966072.jpg
title: NiTi light
tags: prototype model control
modal:
  - img: 11889954_10207114596406433_2522463985584899658_o_10207114596406433.jpg
  - img: ezgif.com-gif-maker.gif
  - img: IMG-20191127-WA0010-300x200.jpg
  - img: 11894545_10207114581966072_1589272026712605774_o_10207114581966072.jpg
  - img: 11892031_10207087731214820_1210169129953186247_n_10207087731214820.jpg
  - img: 11907193_10207087731894837_8767404311496339564_n_10207087731894837.jpg
  - img: ezgif.com-optimize-1.gif
  - img: 11828802_10207063626132208_3432269483034708133_n_10207063626132208.jpg
---

Realization of a product design, POC for a graduation project exhibition. Nitinol heated stems for paper flowers, lit by LEDs, in a faux vase. Animation of the flowers by resistively heating the NiTi wires and PWM control of the LEDs brightness. Design by my wife, Aya Shani, as grduation project in product design at H.I.T..