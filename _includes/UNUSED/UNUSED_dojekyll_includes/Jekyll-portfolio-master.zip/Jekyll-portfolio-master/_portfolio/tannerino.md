---
place: 10
cover: Tannerino-design-concept-1024x728.jpg
title: "Tannerino (electro-Theremin)"
tags: design prototype
link: https://hackaday.io/project/133879-tannerino
modal:
  - img: Tannerino-design-concept-1024x728.jpg
---
A continuous variable frequency MIDI controller based on an Arduino Uno. 