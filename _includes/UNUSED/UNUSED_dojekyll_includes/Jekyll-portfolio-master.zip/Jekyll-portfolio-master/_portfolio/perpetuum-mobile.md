---
place: 2
cover: wheel-right.png
title: Perpetuum Mobile, Shachar Marcus, MUZA, 2019
tags: mechanical design control
modal:
  - img: wheel-front-1.png
  - img: concept-omri.jpg
  - img: ezgif.com-optimize-4.gif
  - img: wheel-right.png
  - img: IMG_20190925_090039.jpg
---

Mechanical design, characterization and selection of drive mechanism / motor, production of shop drawings, supervision on construction. Produced in collaboration with studio Omri Ben Artzi, as an installation in the exhibition "Data Mining", Shachar Marcus, MUZA, 2019.